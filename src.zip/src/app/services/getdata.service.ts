import { Injectable } from '@angular/core';
//import { HttpClient } from '@angular/common/http';
import {HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GetdataService {

 constructor(private http:HttpClient) { }
   /*createAuthorizationHeader(headers: Headers) {
    headers.append('x-access-token', JSON.parse(localStorage.usersessiondata).sessionid); 
  } */

  getProfileDataApi(){
  	/*let headers = new Headers();
  	this.createAuthorizationHeader(headers);*/
  	var requestbody ={
  		email:JSON.parse(localStorage.usersessiondata).email,
  		token:JSON.parse(localStorage.usersessiondata).sessionid
  	}

  	return (this.http.post("http://localhost:4040/getalluser/getuserprofiledata",requestbody));  
  }

  getInboxDataApi(){
    /*let headers = new Headers();
    this.createAuthorizationHeader(headers);*/
    var requestbody ={
      email:JSON.parse(localStorage.usersessiondata).email,
      token:JSON.parse(localStorage.usersessiondata).sessionid 
    }

    return (this.http.post("http://localhost:4040/getusermessages/getmessages",requestbody));  
  }
}
