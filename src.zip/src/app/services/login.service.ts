import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class LoginService {

  constructor(private http:HttpClient) { }

  loginUserApi(loginData){
  	var reqBody = {
        email: loginData.email,
        password: loginData.password
  	}
	return (this.http.post("http://localhost:4040/loginuser",reqBody)); 
   }

}
