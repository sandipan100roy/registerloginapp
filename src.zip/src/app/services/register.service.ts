import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class RegisterService {

  constructor(private http:HttpClient) { }

  getAllFromHttp(registerData){
  	var reqBody = {
  		name: registerData.first_name,
        email: registerData.email,
        password: registerData.password,
        phone: registerData.phone
  	}
	return (this.http.post("http://localhost:4040/registeruser",reqBody));
   }
}
