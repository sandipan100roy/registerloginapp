import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SetdataService {

  constructor(private http:HttpClient) { }

  sendMailDataApi(sendMailData){

	  	let mailList = sendMailData.to.split(',');
	  	var requestBodyArray = [];
	    for(var i=0; i<mailList.length; i++){
	    	var maillistobj ={
	    		firstname:JSON.parse(localStorage.usersessiondata).name,
	    		lastname:"",
	    		from_email:JSON.parse(localStorage.usersessiondata).email,
	    		to_email:mailList[i].trim(),
	    		message:sendMailData.body,
		  		subject:sendMailData.subject,
		  		messagetype:""
	    	}
	  		requestBodyArray.push(maillistobj);
	    }
	    var requestbody ={
	    		requestBodyArray : requestBodyArray,
		  		email:JSON.parse(localStorage.usersessiondata).email,
		  		token:JSON.parse(localStorage.usersessiondata).sessionid
	  	}
	  	return (this.http.post("http://localhost:4040/setusermessages/sendmail",requestbody));
  }

  saveProfilePicDataApi(sendProfilePicData){
  	var requestbody ={
	    		requestBase64data : sendProfilePicData,
		  		email:JSON.parse(localStorage.usersessiondata).email,
		  		token:JSON.parse(localStorage.usersessiondata).sessionid
	  	}
	  	return (this.http.post("http://localhost:4040/setuserprofilepic/profilepic",requestbody));
  }
}
