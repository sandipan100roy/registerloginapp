import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LogoutService {

  constructor(private http: HttpClient) { }

  logoutApi(logoutData){

  	var reqBody = {
        sessionid: logoutData
  	}

	return (this.http.post("http://localhost:4040/logout",reqBody)); 
   }
}
