import { Component, OnInit } from '@angular/core';
import {Request,Response,Router} from "express"; 

import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  title = 'Log In';
  
  constructor(private loginService:LoginService) {}

  ngOnInit() {
  }

  getLoginFormData(registerData){
  	this.loginService.loginUserApi(registerData).
  	subscribe(
  		data => {console.log(data)},
  		err => {console.log(err)}
  	);	
  }

}
