import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router"; 

import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  title = 'Log In';
  errorMessage = '';
  
  constructor(private loginService:LoginService,private router:Router) {}

  ngOnInit() {
  }

  getLoginFormData(registerData){
  	this.loginService.loginUserApi(registerData).
  	subscribe(
  		data => {
        //console.log(data);
        if(data && data[0] && data[0].sessionid){
          var sessiondata = {
          sessionid:data[0].sessionid,
          name:data[0].name,
          email:data[0].email
          }
          localStorage.setItem('usersessiondata',JSON.stringify(sessiondata));
          this.router.navigate(['/home']); 
        }else{
          this.errorMessage = "Incorrect username or password!!";
        }   
      },
  		err => {console.log(err)}
  	);	
  }

}
