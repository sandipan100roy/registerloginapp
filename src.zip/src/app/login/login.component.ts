import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import { FormGroup, FormControl } from '@angular/forms'; 

import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit { 
  title = 'Log In';
  errorMessage = '';
  showReactiveLoginForm = false;

  loginForm : FormGroup; 
  
  constructor(private loginService:LoginService,private router:Router) {}

  ngOnInit() { 
    this.loginForm = new FormGroup({
      email : new FormControl(),
      password : new FormControl();
    }); 
  }

  getLoginFormData(registerData){
    if(this.showReactiveLoginForm)
      registerData = this.loginForm.value; 
  	this.loginService.loginUserApi(registerData). 
  	subscribe(
  		data => {
        //console.log(data);
        if(data && data.sessionid){
          var sessiondata = {
          sessionid:data.sessionid,
          name:data.name,
          email:data.email
          }
          localStorage.setItem('usersessiondata',JSON.stringify(sessiondata));
          this.router.navigate(['/home']);
        }else{
          this.errorMessage = "Incorrect username or password!!";
        }   
      },
  		err => {console.log(err)}
  	);	
  }

  showHideLoginForm(formtype){
    if(formtype == "templatedriven")
      this.showReactiveLoginForm = false;
    else
      this.showReactiveLoginForm = true;
  }

}
