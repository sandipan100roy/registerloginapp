import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import { FormsModule} from '@angular/forms'

import { AppComponent } from './app.component';
import { NewComponent } from './new/new.component'; // NewComponent is the reference of the new component created.
import { ChangeTextDirective } from './change-text.directive'; // The class ChangeTextDirective is also imported from change-text.directive.ts file.
import { PipeCompComponent } from './pipe-comp/pipe-comp.component'; 
import { SqrtPipe } from './pipe-comp/pipe-comp.sqrt';
import { RouteComponent } from './route/route.component';
import { MyserviceService } from './myservice.service';
import { FormExampleComponent } from './form-example/form-example.component';

@NgModule({
  declarations: [
    AppComponent,
    NewComponent,
    ChangeTextDirective, //ChangeTextDirective class is included in the declarations.
    PipeCompComponent,
    SqrtPipe,
    RouteComponent,
    FormExampleComponent 
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot([
    {
    	path:'route',
    	component:RouteComponent
    },
    {
    	path:'form-example',
    	component:FormExampleComponent
    }
    ]),
    HttpModule,
    FormsModule
  ],
  providers: [MyserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
