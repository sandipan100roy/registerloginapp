import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { InboxComponent } from './inbox/inbox.component'; 

import { RegisterService } from './services/register.service';
import { LoginService } from './services/login.service';
import { LogoutService } from './services/logout.service';
import { GetdataService } from './services/getdata.service';

import { FilterPipe } from './pipes/filter.pipe';

import { ReactiveFormsModule } from '@angular/forms'; 

const appRoutes = 
  [
	  { path: 'login', component: LoginComponent },
	  { path: 'register', component: RegisterComponent },
	  { path: '', redirect:'/login', component: LoginComponent },
    { path: 'home', component: HomeComponent }  
  ];

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    HomeComponent,
    InboxComponent,
    FilterPipe
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes), 
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [RegisterService,LoginService,LogoutService,GetdataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
