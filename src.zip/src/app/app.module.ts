import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';

import { RegisterService } from './services/register.service';
import { LoginService } from './services/login.service';
import { LogoutService } from './services/logout.service';

const appRoutes = 
  [
	  { path: 'login', component: LoginComponent },
	  { path: 'register', component: RegisterComponent },
	  { path: '', redirect:'/login', component: LoginComponent },
    { path: 'home', component: HomeComponent }
  ];

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes), 
    FormsModule,
    HttpClientModule
  ],
  providers: [RegisterService,LoginService,LogoutService],
  bootstrap: [AppComponent]
})
export class AppModule { }
