import { Component, OnInit } from '@angular/core';

import {Request,Response,Router} from "express"; 

import { RegisterService } from '../services/register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  title = 'Register';

  constructor(private registerService:RegisterService) {}

  ngOnInit() {
  }

  getRegisterFormData(registerData){
  	this.registerService.getAllFromHttp(registerData).
  	subscribe(
  		data => {console.log(data)},
  		err => {console.log(err)}
  	);	
  }

}
