import { Component, OnInit } from '@angular/core';

import {Request,Response,Router} from "express"; 

import { RegisterService } from '../services/register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html', 
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  title = 'Register';
  errorMessageRegister = '';

  constructor(private registerService:RegisterService) {}

  ngOnInit() {
  }

  getRegisterFormData(registerData){
  	this.registerService.getAllFromHttp(registerData).
  	subscribe(
  		data => {console.log(data)
        if(data && data.code && data.code == 2){
          this.errorMessageRegister = data.msg;
        }
      },
  		err => {console.log(err)} 
  	);	
  }

}
