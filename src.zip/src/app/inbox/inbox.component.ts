import { Component, OnInit } from '@angular/core';
import { GetdataService } from '../services/getdata.service';
import { SetdataService } from '../services/setdata.service';

@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.css']
})
export class InboxComponent implements OnInit {

  mailsent = false;
  messageData ;
  constructor(private getdataService:GetdataService,private setdataService:SetdataService) { }

  ngOnInit() {
  // Get the element with id="defaultOpen" and click on it
     this.mailsent = false;
  	 this.getInboxData();
     document.getElementById("defaultOpen").click();
  }

  openMailBox(evt, cityName) {

    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    this.mailsent = false;
    //evt.currentTarget.className += " active"; 
 }

 getInboxData(){
  	this.getdataService.getInboxDataApi().
  	subscribe(
  		data => {
        if(data[0] || data)
          this.messageData = data;
      },
  		err => {console.log(err)}
  	);
  }

  sendMailApi(sendMailData){
    this.setdataService.sendMailDataApi(sendMailData).
    subscribe(
      data => { 
          if(data && data.responsecode && data.responsecode.insertedCount && data.responsecode.insertedCount > 0){
            this.mailsent = true;
            this.getInboxData();
            }
          else{
            this.mailsent = false;
          }
      },
      err =>{ console.log(err);}
    );
  }

}
