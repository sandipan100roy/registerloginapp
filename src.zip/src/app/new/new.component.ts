import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {
  newComponent = "Entered in new component created..";
  // declared array of months
  months = ["January","February","March","April",
  			"May","June","July","August",
  			"September","October","November","December"];

  isAvailable = true;

  ifElse = false;

  ifThenElse = false;

  isTemplateExample = true;
  myClickFuntion(event){
  	alert("Button is clicked");
  	console.log(event);
  }

  myChangeFuntion(event){
  	alert("Dropdown is changed");
  	console.log(event);
  }

  myTemplate1(val){
  	if(val==1){
  		this.isTemplateExample = true;
  	}else{
  		this.isTemplateExample = false;
  	}
  }
  constructor() { }

  ngOnInit() {
  }

}
