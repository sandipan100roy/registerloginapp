import {Pipe, PipeTransform} from '@angular/core';

@Pipe({   // This is @Pipe directive
	name:'sqrt'
})

export class SqrtPipe implements PipeTransform{

	transform(val: number) : number {
		return Math.sqrt(val);
	}
}