import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipe-comp',
  templateUrl: './pipe-comp.component.html',
  styleUrls: ['./pipe-comp.component.css']
})
export class PipeCompComponent implements OnInit {

  pipeTitle = "Welcome to Pipe Examples!!";
  todayDate = new Date();
  jsonValue = {name:"Sandipan", age:"25", address:{a1:"Asansol",a2:"Noida"}};
  months = ["January","February","March","April",
  			"May","June","July","August",
  			"September","October","November","December"];

  constructor() { }

  ngOnInit() {
  }

} 
