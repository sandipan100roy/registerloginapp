import { Injectable } from '@angular/core';
import { Http } from '@angular/http';


@Injectable()
export class MyserviceService {
  
  playerJson: string = "http://localhost:4200/assets/";
  players:any;
  constructor(private http : Http) { 
  	this.players = this.getPlayersFromHttp();
  	//console.log(this.players);
  }
  showTodayDate(){
  	let date = new Date();
  	return date;
  }

   getPlayersFromHttp(){
	return (this.http.get("http://localhost:4200/assets/players.json"));
   }
}
