import { Component, OnInit } from '@angular/core';
import { MyserviceService } from './../myservice.service';
import 'rxjs/add/operator/map';


@Component({
  selector: 'app-route',
  templateUrl: './route.component.html',
  styleUrls: ['./route.component.css']
})
export class RouteComponent implements OnInit {
  todayDate:any;
  httpData:any;
  constructor(private myserviceService:MyserviceService) {} 

  ngOnInit() {
  	this.todayDate = this.myserviceService.showTodayDate();
  	this.myserviceService.getPlayersFromHttp().
  	map((response) => response.json()).
  	subscribe(
  		data => {this.displayData(data)},
  		err => {console.log(err)}
  	);
  }

  displayData(data){
    this.httpData = data;
    console.log(this.httpData);
  }

}
