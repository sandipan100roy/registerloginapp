import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(value: any, args?: any): any {
  	let userEmail = JSON.parse(localStorage.usersessiondata).email;
    let filteredMessageData = [] ;
    for(var i =0; i<value.length; i++){
    	if(value[i][args] == userEmail)
    		filteredMessageData.push(value[i]);  	
    }
    return filteredMessageData;
  }

}
