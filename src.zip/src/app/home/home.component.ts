import { Component, OnInit } from '@angular/core';
import { LogoutService } from '../services/logout.service';
import { Router } from "@angular/router"; 

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  title='Home';
  username = JSON.parse(localStorage.usersessiondata).name;
  constructor(private logoutService:LogoutService, private router:Router) { }

  ngOnInit() {}

  logoutApi(){

  	if(localStorage && localStorage.usersessiondata){
  		var usersessiondata = JSON.parse(localStorage.usersessiondata);
  		if(usersessiondata.sessionid)
  			var logoutData = usersessiondata.sessionid;
  	}

  	this.logoutService.logoutApi(logoutData).
  	subscribe(
  		data => {
  			if(data && data.code && data.code.n && data.code.n == 1){
  				localStorage.clear();
  				this.router.navigate(['/login']);
  			}
  		},
  		err => {console.log(err)}
  	);
  }

}
