import { Component, OnInit } from '@angular/core';
import { LogoutService } from '../services/logout.service';
import { GetdataService } from '../services/getdata.service';
import { SetdataService } from '../services/setdata.service';
import { Router } from "@angular/router"; 

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  title='Home';
  username = JSON.parse(localStorage.usersessiondata).name;
  profileData :any;
  showProfile = false;
  constructor(private logoutService:LogoutService, private router:Router,private getdataService:GetdataService,private setdataService:SetdataService) { }

  ngOnInit() {}

  logoutApi(){ 

  	if(localStorage && localStorage.usersessiondata){
  		var usersessiondata = JSON.parse(localStorage.usersessiondata);
  		if(usersessiondata.sessionid)
  			var logoutData = usersessiondata.sessionid;
  	}

  	this.logoutService.logoutApi(logoutData).
  	subscribe(
  		data => {
  			console.log(data);
  			if(data && data.code && data.code.n && data.code.n == 1){ 
  				localStorage.clear();
  				this.router.navigate(['/login']);
  			}
  		},
  		err => {console.log(err)}
  	);
  }

  getProfileData(){
    this.showProfile = true;
  	this.getdataService.getProfileDataApi().
  	subscribe(
  		data => {
        console.log(data[0]);
        if((data[0] && data[0].success) || data.success)
          this.profileData = data;
        else
          this.router.navigate(['/login']);
      },
  		err => {console.log(err)}
  	);
  }

  hideProfile(){
    this.showProfile = false;
  }

  uploadProfilePic(event){
     var files = event.target.files;
      var file = files[0];

    if (files && file) {
        var reader = new FileReader();

        reader.onload =this._handleReaderLoaded.bind(this);

        reader.readAsBinaryString(file);
    }
  }

  _handleReaderLoaded(readerEvt) {
     var binaryString = readerEvt.target.result;
            this.base64textString= btoa(binaryString);
            //console.log(this.base64textString);
             this.setdataService.saveProfilePicDataApi(this.base64textString).
                subscribe(
                  data => { 
                      console.log(data);
                      this.getProfileData();
                  },
                  err =>{ console.log(err);}
                );
    }

}
